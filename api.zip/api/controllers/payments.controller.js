const Payment = require('../models/payments.model');

const createPayment = async (req, res) => {
    const payment = req.body;
    const newPayment = await Payment.createPayment(payment);
    if (!newPayment) {
        return res.status(400).json({ message: 'Payment creation failed' });
    }
    res.status(201).json({ message: 'Payment created successfully', newPayment });
};  

const getPaymentById = async (req, res) => {
    const paymentId = req.params.id;
    const payment = await Payment.getPaymentById(paymentId);
    if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
    }
    res.status(200).json({ message: 'Payment retrieved successfully', payment });
};

const updatePayment = async (req, res) => {
    const paymentId = req.params.id;
    const payment = req.body;
    const updatedPayment = await Payment.updatePayment(paymentId, payment);
    if (!updatedPayment) {
        return res.status(400).json({ message: 'Payment update failed' });
    }
    res.status(200).json({ message: 'Payment updated successfully', updatedPayment });
};  

const deletePayment = async (req, res) => {
    const paymentId = req.params.id;
    const deletedPayment = await Payment.deletePayment(paymentId);
    if (!deletedPayment) {
        return res.status(400).json({ message: 'Payment deletion failed' });
    }
    res.status(200).json({ message: 'Payment deleted successfully', deletedPayment });
};  

const getAllPayments = async (req, res) => {
    const payments = await Payment.getAllPayments();
    if (!payments) {
        return res.status(404).json({ message: 'Payments not found' });
    }
    res.status(200).json({ message: 'Payments retrieved successfully', payments });
};  

const getPaymentsByBookingId = async (req, res) => {
    const bookingId = req.params.id;
    const payments = await Payment.getPaymentsByBookingId(bookingId);
    if (!payments) {
        return res.status(404).json({ message: 'Payments not found' });
    }
    res.status(200).json({ message: 'Payments retrieved successfully', payments });
};  

const getPaymentsByPaymentMethod = async (req, res) => {
    const paymentMethod = req.params.paymentMethod;
    const payments = await Payment.getPaymentsByPaymentMethod(paymentMethod);
    if (!payments) {
        return res.status(404).json({ message: 'Payments not found' });
    }
    res.status(200).json({ message: 'Payments retrieved successfully', payments });
};  

const getPaymentsByTransactionId = async (req, res) => {
    const transactionId = req.params.transactionId;
    const payments = await Payment.getPaymentsByTransactionId(transactionId);
    if (!payments) {
        return res.status(404).json({ message: 'Payments not found' });
    }
    res.status(200).json({ message: 'Payments retrieved successfully', payments });
};  

const getPaymentsByStatus = async (req, res) => {
    const status = req.params.status;
    const payments = await Payment.getPaymentsByStatus(status);
    if (!payments) {
        return res.status(404).json({ message: 'Payments not found' });
    }
    res.status(200).json({ message: 'Payments retrieved successfully', payments });
}; 

module.exports = {
    createPayment,
    getPaymentById,
    updatePayment,
    deletePayment,
    getAllPayments,
    getPaymentsByBookingId, 
    getPaymentsByPaymentMethod,
    getPaymentsByTransactionId,
    getPaymentsByStatus
};  