const pool = require('../config/db');

const PasswordReset = {
    reset_id: {
        type: Number,
        autoIncrement: true,
        primaryKey: true
    },
    email: {
        type: String,
        allowNull: false
    },
    token: {
        type: String,
        allowNull: false
    },
    expires_at: {
        type: Date,
        allowNull: false
    },
    updated_at: {
        type: Date,
        allowNull: false,
        defaultValue: Date.now
    }
};


module.exports = {
    createPasswordReset: async (passwordReset) => {
        const query = `INSERT INTO password_resets (email, token, expires_at) VALUES ($1, $2, $3)`;
        const result = await pool.query(query, [passwordReset.email, passwordReset.token, passwordReset.expires_at]);
        return result.rows[0];
    },
    getPasswordResetById: async (resetId) => {
        const query = `SELECT * FROM password_resets WHERE reset_id = $1`;
        const result = await pool.query(query, [resetId]);
        return result.rows[0];
    },
    updatePasswordReset: async (resetId, passwordReset) => {
        const query = `UPDATE password_resets SET email = $1, token = $2, expires_at = $3 WHERE reset_id = $4`; 
        const result = await pool.query(query, [passwordReset.email, passwordReset.token, passwordReset.expires_at, resetId]);
        return result.rows[0];
    },
    deletePasswordReset: async (resetId) => {
        const query = `DELETE FROM password_resets WHERE reset_id = $1`;    
        const result = await pool.query(query, [resetId]);
        return result.rows[0];
    },
    getAllPasswordResets: async () => {
        const query = `SELECT * FROM password_resets`;
        const result = await pool.query(query);
        return result.rows;
    },
    findByEmail: async (email) => {
        const query = `SELECT * FROM password_resets WHERE email = $1`;
        const result = await pool.query(query, [email]);
        return result.rows[0];
    },
    findByToken: async (token) => {
        const query = `SELECT * FROM password_resets WHERE token = $1`;
        const result = await pool.query(query, [token]);
        return result.rows[0];
    },
    deleteByEmail: async (email) => {
        const query = `DELETE FROM password_resets WHERE email = $1`;
        const result = await pool.query(query, [email]);
        return result.rows[0];
    },
    deleteByToken: async (token) => {
        const query = `DELETE FROM password_resets WHERE token = $1`;
        const result = await pool.query(query, [token]);
        return result.rows[0];
    }   
}